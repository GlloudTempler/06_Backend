package com.example.jpacustomexam.model;

import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;

/**
 * packageName : com.example.jpacustomexam.model
 * fileName : Comment
 * author : GGG
 * date : 2023-10-25
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-10-25         GGG          최초 생성
 */
@Entity
@Table(name="TB_COMMENT")
@SequenceGenerator(
        name = "SQ_COMMENT_GENERATOR"
        , sequenceName = "SQ_COMMENT"
        , initialValue = 1
        , allocationSize = 1
)
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@DynamicInsert
@DynamicUpdate
public class Comment extends BaseTimeEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE
            , generator = "SQ_COMMENT_GENERATOR"
    )
    @Column(columnDefinition="NUMBER")
    private Integer cid;

    @Column(columnDefinition="VARCHAR2(255)")
    private String commentContent;

    @Column(columnDefinition="VARCHAR2(255)")
    private String commentWriter;

    @Column(columnDefinition="NUMBER")
    private String bidNumber;
}
