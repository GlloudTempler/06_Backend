package com.example.jpacustomexam.repository;

import com.example.jpacustomexam.dto.BoardCommentDto;
import com.example.jpacustomexam.model.Board;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * packageName : com.example.jpacustomexam.repository
 * fileName : BoardRepository
 * author : GGG
 * date : 2023-10-25
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-10-25         GGG          최초 생성
 */
@Repository
public interface BoardRepository extends JpaRepository<Board, Integer> {
    Page<Board> findAllByBoardTitleContaining(String boardTitle, Pageable pageable);

    @Query(value = "SELECT B.*, B.BID, B.BOARD_TITLE, B.BOARD_CONTENT, B.BOARD_WRITER " +
            "FROM TB_BOARD B, TB_COMMENT C " +
            "WHERE B.BID = C.BID ",
            countQuery = "SELECT COUNT(*) " +
                    "FROM TB_BOARD B, TB_COMMENT E " +
                    "WHERE B.BID = C.BID ",
            nativeQuery = true)
    Page<BoardCommentDto> selectNativeJoinPage(Pageable pageable);


}
