package com.example.jpacustomexam.controller;

import com.example.jpacustomexam.model.Board;
import com.example.jpacustomexam.service.BoardService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * packageName : com.example.jpacustomexam.controller
 * fileName : BoardController
 * author : GGG
 * date : 2023-10-25
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-10-25         GGG          최초 생성
 */
@RestController
@Slf4j
@RequestMapping("/api")
public class BoardController {
    @Autowired
    BoardService boardService;

    @GetMapping("/boards")
    public ResponseEntity<Object> findAll(
            @RequestParam(defaultValue = "") String boardTitle,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "3") int size
    ) {
        try {
            // 페이지 변수 저장 (page : 현재 페이지 번호 , size : 1페이지 당 개수)
            // 함수 매개변수 : Pagable(위의 값을 넣기)
            Pageable pageable = PageRequest.of(page, size);

            Page<Board> boardPage = boardService.findAllByBoardTitleContaining(boardTitle, pageable);

            Map<String, Object> response = new HashMap<>();
            response.put("board", boardPage.getContent()); // 부서 배열
            response.put("currentPage", boardPage.getNumber()); // 현재 페이지 번호
            response.put("totalItems", boardPage.getTotalElements()); // 총 건수
            response.put("totalPages", boardPage.getTotalPages()); // 총 페이지 건수

            if (boardPage.isEmpty() == false) {
                // 성공
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                // 데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/boards")
    public ResponseEntity<Object> createBoard(@RequestBody Board board) {
        try {
            Board board1 = boardService.save(board);

            return new ResponseEntity<>(board1, HttpStatus.OK);
        } catch (Exception e) {
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/boards/{bid}")
    public ResponseEntity<Object> updateDept(
            @PathVariable int bid,
            @RequestBody Board board
    ) {
        try {
            Board board1 = boardService.save(board);
            return new ResponseEntity<>(board1, HttpStatus.OK);
        } catch (Exception e) {
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/boards/{bid}")
    public ResponseEntity<Object> findByID(@PathVariable int bid) {
        try {
            Optional<Board> optionalBoard = boardService.findByID(bid);

            if (optionalBoard.isPresent()) {
                return new ResponseEntity<>(optionalBoard, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);


        }
    }

    @DeleteMapping("/boards/deletion/{bid}")
    public ResponseEntity<Object> deleteDept(@PathVariable int bid) {
        try{
            boolean bSuccess = boardService.removeByID(bid);
            if(bSuccess == true) {
                return new ResponseEntity<>(HttpStatus.OK);
            }
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }catch (Exception e) {
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/boards/paging")
    public ResponseEntity<Object> getEmpAllPage(Pageable pageable) {
        try {
            Page<Board> page
                    = boardService.findAllPage(pageable);

//          todo: Map 자료구조 정보 저장 : 1) 사원객체, 2) 페이징 정보 (3개)
            Map<String, Object> response = new HashMap<>();
            response.put("board", page.getContent()); // 사원 객체
            response.put("currentPage", page.getNumber()); // 현재페이지번호
            response.put("totalItems", page.getTotalElements()); // 전체테이블건수
            response.put("totalPages", page.getTotalPages()); // 전체 페이지 수

            if (page.isEmpty() == false) {
//                성공
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
//                데이터 없음
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

        } catch (Exception e) {
            log.debug(e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    }
