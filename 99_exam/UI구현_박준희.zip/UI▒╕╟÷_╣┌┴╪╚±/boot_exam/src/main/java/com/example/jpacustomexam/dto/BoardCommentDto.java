package com.example.jpacustomexam.dto;

/**
 * packageName : com.example.jpacustomexam.dto
 * fileName : BoardDto
 * author : GGG
 * date : 2023-10-25
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-10-25         GGG          최초 생성
 */
public interface BoardCommentDto {
    Integer getBid();

    String getBoardTitle();
    String getBoarContent();
    String getBoardWriter();
    String getViewCnt();

    Integer getCid();

    String getCommentContent();
    String getCommentWriter();

}
