package com.example.jpacustomexam.service;

import com.example.jpacustomexam.model.Board;
import com.example.jpacustomexam.model.Comment;
import com.example.jpacustomexam.repository.BoardRepository;
import com.example.jpacustomexam.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * packageName : com.example.jpacustomexam.service
 * fileName : CommentService
 * author : GGG
 * date : 2023-10-25
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-10-25         GGG          최초 생성
 */
@Service
public class CommentService {
    @Autowired
    CommentRepository commentRepository;

    public Page<Comment> findAll(Pageable pageable) {
        Page<Comment> page = commentRepository.findAll(pageable);

        return page;
    }

    public Page<Comment> findAllByBidNumberContaining(int bid, Pageable pageable) {
        Page<Comment> page = commentRepository.findAllByBidNumberContaining(bid, pageable);
        return page;
    }

    public Comment save(Comment comment) {
        Comment board1 = commentRepository.save(comment);
        return board1;
    }

    public Optional<Comment> findByID(int cid) {
        Optional<Comment> optionalDept = commentRepository.findById(cid);
        return optionalDept;
    }

    public boolean removeByID(int cid) {
        if(commentRepository.existsById(cid)) {
            commentRepository.deleteById(cid);
        }
        return false;
    }
}
