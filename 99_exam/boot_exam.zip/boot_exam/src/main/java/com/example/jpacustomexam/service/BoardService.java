package com.example.jpacustomexam.service;

import com.example.jpacustomexam.model.Board;
import com.example.jpacustomexam.repository.BoardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * packageName : com.example.jpacustomexam.service
 * fileName : BoardService
 * author : GGG
 * date : 2023-10-25
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-10-25         GGG          최초 생성
 */
@Service
public class BoardService {
    @Autowired
    BoardRepository boardRepository;

    public Page<Board> findAll(Pageable pageable) {
        Page<Board> page = boardRepository.findAll(pageable);

        return page;
    }

    public Page<Board> findAllByBoardTitleContaining(String boardTitle, Pageable pageable) {
        Page<Board> page = boardRepository.findAllByBoardTitleContaining(boardTitle, pageable);
        return page;
    }

    public Board save(Board board) {
        Board board1 = boardRepository.save(board);
        return board1;
    }

    public Optional<Board> findByID(int bid) {
        Optional<Board> optionalDept = boardRepository.findById(bid);
        return optionalDept;
    }

    public boolean removeByID(int bid) {
        if(boardRepository.existsById(bid)) {
            boardRepository.deleteById(bid);
            return true;
        }
        return false;
    }

    public Page<Board> findAllPage(Pageable pageable) {
        Page<Board> page = boardRepository.findAll(pageable);
        return page;
    }

}
